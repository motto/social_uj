<?php

namespace Coinbase\Wallet\Exception;

class InvalidRequestException extends BadRequestException
{
}
