<?php

namespace Coinbase\Wallet\Exception;

class RuntimeException extends \RuntimeException implements Exception
{
}
