<?php

namespace Coinbase\Wallet\Exception;

class ParamRequiredException extends BadRequestException
{
}
