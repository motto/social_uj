<?php

namespace Coinbase\Wallet\Exception;

class InvalidTokenException extends UnauthorizedException
{
}
